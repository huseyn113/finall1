﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _23._11._2020.k101
{
   public static class utili
    {
        public static bool IsEmpty(string[] myarr,string text)
        {
            foreach (var ar in myarr)
            {
                if(ar==text)
                {
                    return false;
                }
            }
            return true;
        }

    }
}
