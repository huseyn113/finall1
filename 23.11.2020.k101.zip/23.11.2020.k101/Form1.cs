﻿using _23._11._2020.k101.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _23._11._2020.k101
{
    public partial class Form1 : Form
    {


        Entities db = new Entities();
        Umumi11 umumi11;

        public void fillmey22()
        {
            cmmey1.Items.AddRange(db.Meydancas.Select(x => x.Name).ToArray());
        }


        public void fillotaq22()
        {
            cmota.Items.AddRange(db.Otaqlars.Select(x => x.Name).ToArray());
        }

        public void filldatagrid22()
        {
            dtgrid.DataSource = db.Umumi11.Where(x=>!x.IsActive).Select(x => new
            {
                x.ID,
                Meydanca = x.Meydanca.Name,
                Otaqlar = x.Otaqlar.Name,

                MusteriAdi = x.MusteriAdi,
                x.MusteriNomresi,
                x.Qiymetler,
                x.NeceNefer,
                x.Tarix

            }).ToList();
        }


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            fillmey22();
            fillotaq22();
            filldatagrid22();
          
        }


        private void cmrezerv_Click(object sender, EventArgs e)
        {

            Umumi11 mln = new Umumi11();
            mln.MeydancaID = 1;
            mln.OtaqID = 1;
          
            mln.MusteriAdi = txtmusteri2.Text;
            mln.MusteriNomresi = Convert.ToInt32(cnomre.Value);
         


            mln.Qiymetler = Convert.ToInt32(cmqiymet.Value);
            mln.NeceNefer = Convert.ToInt32(cmnefer.Value);
            mln.Tarix = cmtarix.Value;
            db.Umumi11.Add(mln);
            db.SaveChanges();
            filldatagrid22();
            MessageBox.Show("rezerv olundu");

        }

        private void dtgrid_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int mln=(int)dtgrid.Rows[e.RowIndex].Cells[0].Value;
            umumi11 = db.Umumi11.Find(mln);
            txtmusteri2.Text = umumi11.MusteriAdi;
            cnomre.Value = umumi11.MusteriNomresi;
            cmmey1.Text = umumi11.Meydanca.Name;
            cmota.Text = umumi11.Otaqlar.Name;
            cmqiymet.Value = umumi11.Qiymetler;
            cmnefer.Value = umumi11.NeceNefer;
            cmtarix.Value = umumi11.Tarix;



        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            umumi11.IsActive = true;
            db.SaveChanges();
            filldatagrid22();
        }
    }
}
