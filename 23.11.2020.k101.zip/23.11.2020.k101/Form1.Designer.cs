﻿namespace _23._11._2020.k101
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.dtgrid = new System.Windows.Forms.DataGridView();
            this.txtmusteri2 = new System.Windows.Forms.TextBox();
            this.cnomre = new System.Windows.Forms.NumericUpDown();
            this.cmqiymet = new System.Windows.Forms.NumericUpDown();
            this.cmnefer = new System.Windows.Forms.NumericUpDown();
            this.cmtarix = new System.Windows.Forms.DateTimePicker();
            this.cmmey1 = new System.Windows.Forms.ComboBox();
            this.cmota = new System.Windows.Forms.ComboBox();
            this.cmrezerv = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnomre)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmqiymet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmnefer)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "MusteriAdi";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(12, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(142, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "MusteriNomresi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(188, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 24);
            this.label3.TabIndex = 2;
            this.label3.Text = "Meydanca";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(188, 76);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Otaqlar";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(410, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 24);
            this.label5.TabIndex = 4;
            this.label5.Text = "Qiymetler";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(410, 76);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 24);
            this.label6.TabIndex = 5;
            this.label6.Text = "NeceNefer";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(584, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 24);
            this.label7.TabIndex = 6;
            this.label7.Text = "Tarix";
            // 
            // dtgrid
            // 
            this.dtgrid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgrid.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgrid.Location = new System.Drawing.Point(6, 213);
            this.dtgrid.Name = "dtgrid";
            this.dtgrid.Size = new System.Drawing.Size(782, 225);
            this.dtgrid.TabIndex = 7;
            this.dtgrid.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgrid_RowHeaderMouseDoubleClick);
            // 
            // txtmusteri2
            // 
            this.txtmusteri2.Location = new System.Drawing.Point(16, 36);
            this.txtmusteri2.Name = "txtmusteri2";
            this.txtmusteri2.Size = new System.Drawing.Size(100, 20);
            this.txtmusteri2.TabIndex = 8;
            // 
            // cnomre
            // 
            this.cnomre.Location = new System.Drawing.Point(16, 114);
            this.cnomre.Maximum = new decimal(new int[] {
            -727379968,
            232,
            0,
            0});
            this.cnomre.Name = "cnomre";
            this.cnomre.Size = new System.Drawing.Size(114, 20);
            this.cnomre.TabIndex = 9;
            // 
            // cmqiymet
            // 
            this.cmqiymet.Location = new System.Drawing.Point(414, 37);
            this.cmqiymet.Maximum = new decimal(new int[] {
            1874919424,
            2328306,
            0,
            0});
            this.cmqiymet.Name = "cmqiymet";
            this.cmqiymet.Size = new System.Drawing.Size(114, 20);
            this.cmqiymet.TabIndex = 10;
            // 
            // cmnefer
            // 
            this.cmnefer.Location = new System.Drawing.Point(414, 103);
            this.cmnefer.Maximum = new decimal(new int[] {
            -1530494976,
            232830,
            0,
            0});
            this.cmnefer.Name = "cmnefer";
            this.cmnefer.Size = new System.Drawing.Size(114, 20);
            this.cmnefer.TabIndex = 11;
            // 
            // cmtarix
            // 
            this.cmtarix.Location = new System.Drawing.Point(588, 37);
            this.cmtarix.Name = "cmtarix";
            this.cmtarix.Size = new System.Drawing.Size(200, 20);
            this.cmtarix.TabIndex = 12;
            // 
            // cmmey1
            // 
            this.cmmey1.FormattingEnabled = true;
            this.cmmey1.Location = new System.Drawing.Point(192, 40);
            this.cmmey1.Name = "cmmey1";
            this.cmmey1.Size = new System.Drawing.Size(121, 21);
            this.cmmey1.TabIndex = 32;
            // 
            // cmota
            // 
            this.cmota.FormattingEnabled = true;
            this.cmota.Location = new System.Drawing.Point(192, 113);
            this.cmota.Name = "cmota";
            this.cmota.Size = new System.Drawing.Size(121, 21);
            this.cmota.TabIndex = 33;
            // 
            // cmrezerv
            // 
            this.cmrezerv.Location = new System.Drawing.Point(588, 100);
            this.cmrezerv.Name = "cmrezerv";
            this.cmrezerv.Size = new System.Drawing.Size(189, 34);
            this.cmrezerv.TabIndex = 34;
            this.cmrezerv.Text = "REZERV OL";
            this.cmrezerv.UseVisualStyleBackColor = true;
            this.cmrezerv.Click += new System.EventHandler(this.cmrezerv_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(298, 173);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(96, 22);
            this.btndelete.TabIndex = 35;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.cmrezerv);
            this.Controls.Add(this.cmota);
            this.Controls.Add(this.cmmey1);
            this.Controls.Add(this.cmtarix);
            this.Controls.Add(this.cmnefer);
            this.Controls.Add(this.cmqiymet);
            this.Controls.Add(this.cnomre);
            this.Controls.Add(this.txtmusteri2);
            this.Controls.Add(this.dtgrid);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnomre)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmqiymet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmnefer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView dtgrid;
        private System.Windows.Forms.TextBox txtmusteri2;
        private System.Windows.Forms.NumericUpDown cnomre;
        private System.Windows.Forms.NumericUpDown cmqiymet;
        private System.Windows.Forms.NumericUpDown cmnefer;
        private System.Windows.Forms.DateTimePicker cmtarix;
        private System.Windows.Forms.ComboBox cmmey1;
        private System.Windows.Forms.ComboBox cmota;
        private System.Windows.Forms.Button cmrezerv;
        private System.Windows.Forms.Button btndelete;
    }
}

